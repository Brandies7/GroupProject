﻿namespace ServerNotifications.Web.Models
{
    public class Administrator
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
    }
}